<?php

    require 'simple_html_dom.php';

    function getPlaylistVideoId($html, $file) {
        foreach($html->find('tr') as $ele) {
            if(isset($ele->attr['data-video-id'])) {
                fwrite($file, $ele->attr['data-video-id'] . "\n");
            }
        }
    }

    $file = fopen("result.txt", "w") or die("Unable to open file!");
    $main_page = file_get_contents("https://www.youtube.com/playlist?list=PL_s_GkTFdaE98F_Oe5wEht3P_IlQACiMj");

    $html = new simple_html_dom();
    $html->load($main_page);
    getPlaylistVideoId($html, $file);

    while(count($html->find('button[class=load-more-button]')) != 0) {

        $data = file_get_contents('https://www.youtube.com' . $html->find('button[class=load-more-button]', 0)->attr['data-uix-load-more-href']);

        echo $data;

        $data = json_decode($data, true)['content_html'];
        $html->load($data);
        getPlaylistVideoId($html, $file);
    }

    fclose($file);
?>
