<?php
    require 'simple_html_dom.php';
    require 'fileInfo.php';
    require 'video_data.php';

    // The main function
    function main($link, $format) {
        $playlist_template = "https://www.youtube.com/playlist?list=";
        $video_template = "https://www.youtube.com/watch?v=";
        $channel_template = "https://www.youtube.com/channel/";
        $user_template = "https://www.youtube.com/user/";

        $output_dir = getcwd() . '/downloads/';
        $playlist = false;
        $channel = false;
        $user = false;

        $vid_array = array();
        parse_str($link, $parser);

        if(isset($parser['list'])) {
            // a playlist video
            array_push($vid_array, $link);
        }
        else if(isset($parser['https://www_youtube_com/watch?v'])) {
            // a single video
            array_push($vid_array, $link);
        }
        else if(isset($parser['https://www_youtube_com/playlist?list'])) {
            // a playlist
            $vid_array = getPlaylistVideos($link);
            $playlist = true;
        }
        else {
            echo "others\n";
        }

        // prints the video link
        $vid_counter = 1;
        foreach($vid_array as $link) {
            if($playlist) {
                $link = $video_template . $link;
            }

            $data = getVideoUrl($link, $format);

            if($data !== false) {
                $size = curl_get_file_size($data[0]);
                echo '<a href='. $data[0] . ' download>' . $vid_counter++ . ' '. $data[1] . " ($size) </a><br />";
            }
            else {
                echo "Error in fetching url\n";
            }
        }
    }

	if(isset($_POST['link']) && isset($_POST['format'])) {
		main($_POST['link'], $_POST['format']);
	}
    else {
        main("https://www.youtube.com/watch?v=2Swn5qnZP20", "mp4");
    }
?>
