// A function which takes in user inputs
function getUserInput() {
    echo "\nEnter the video/playlist/channel url: ";
    $handle = fopen ("php://stdin","r");
    $link = trim(fgets($handle));

    echo "\nEnter the file format you wish to download: ";
    $format = trim(fgets($handle));
    return array($link, $format);
}


// A function which downloads the file
function download($url, $title, $output_dir) {
    $video = fopen($url, 'r');
    $output_file = fopen($output_dir . $title . '.mp4', 'w');

    if($video !== false && $output_file !== false) {
        stream_copy_to_stream($video, $output_file);
    }
    else {
        fclose($video);
        fclose($output_file);
        return false;
    }

    fclose($video);
    fclose($output_file);
    return true;
}