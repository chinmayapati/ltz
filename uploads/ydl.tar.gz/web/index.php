<!DOCTYPE html>
<html>
    <head>
        <title>Youtube Downloader</title>
        <link href="index.css" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Devonshire" rel="stylesheet">
    </head>
    <body>
        <h1>APEX Downloader</h1>
        <p class="sub-title"> Downloading youtube videos was never so easy...</p>
        <div class="form-container">
            <div class="user-inputs">
                <input type="url" id="link" name="link" placeholder="Paste the youtube video / playlist / channel link here.." autocomplete="off" />
                <select id="fmt" name="format">
                    <option selected>MP4 720</option>
                    <option>MP4 480</option>
                    <option>MP4 360</option>
                </select>
                <input type="submit" onclick="getVideos()" />
            0</div>

            <div class="meter">
                <span style="width: 100%"></span>
            </div>

            <div class="section">Bulk Video Download Section</div>
            <div class="multi-download">
                Your Download links will appear here..<br /><br />
                Tip: copy the text and open your download manager ex. IDM and add a batch download from clipboard
            </div>

            <div class="section">Individual Video Download Section</div>
        </div>
        <script type="text/javascript">

            $('form button').on("click",function(e){
                e.preventDefault;
            });
                
                alert(input_text);
                alert(format);
            }
        </script>
    </body>
</html>
