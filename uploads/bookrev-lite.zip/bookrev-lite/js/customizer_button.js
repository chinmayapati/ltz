jQuery( document ).ready(function() { 
    jQuery('#customize-footer-actions').append('<a style="position: fixed;bottom: 7px;left: 127px;" href="https://themeisle.com/themes/bookrev/" class="button" target="_blank">View PRO version</a>');

});