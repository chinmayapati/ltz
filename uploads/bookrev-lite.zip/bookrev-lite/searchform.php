			<div class="search-form">

                <form role="search" action="<?php echo site_url('/'); ?>" method="get">

                    <input type="text" name="s" placeholder="<?php _e('Search for something','book-rev-lite'); ?>">

                </form>

                <span class="search-icon"><i class="fa fa-search"></i></span>

            </div><!-- end #search-form -->